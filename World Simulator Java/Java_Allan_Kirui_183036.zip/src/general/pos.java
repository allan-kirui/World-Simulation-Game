package general;

public class pos {
    public int x;
    public int y;

    public pos() {
    }

    public pos(int i, int i1) {
        x = i;
        y = i1;
    }
}
